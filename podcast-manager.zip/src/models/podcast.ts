
export interface Podcast {
    id?: string;
    title: string;
    description: string;
}
